
document.addEventListener("DOMContentLoaded", function () {
    const menuList = document.getElementById("menu-list");
    const searchBar = document.getElementById("search-bar");

    // 調酒分類按鈕
    document.querySelectorAll(".menu-category").forEach(button => {
        button.addEventListener("click", function () {
            const category = this.getAttribute("data-category");
            document.querySelectorAll(".menu-item").forEach(item => {
                if (category === "all" || item.getAttribute("data-category") === category) {
                    item.style.display = "block";
                } else {
                    item.style.display = "none";
                }
            });
        });
    });

    // 設定搜尋功能
    searchBar.addEventListener("input", function () {
        const keyword = searchBar.value.toLowerCase();
        document.querySelectorAll(".menu-item").forEach(item => {
            const name = item.getAttribute("data-name").toLowerCase();
            if (name.includes(keyword)) {
                item.style.display = "block";
            } else {
                item.style.display = "none";
            }
        });
    });

    // 讀取 `img/` 目錄中的圖片
    fetch("data.json")
        .then(response => response.json())
        .then(images => {
            const menuList = document.getElementById("menu-list");
            images.forEach(item => {
                const imgElement = document.createElement("div");
                imgElement.classList.add("col-md-5", "col-xl-3", "my-3", "menu-item");
                imgElement.setAttribute("data-category", item.category);
                imgElement.setAttribute("data-name", item.name.toLowerCase());

                imgElement.innerHTML = `
                <img src="${item.file}" alt="${item.name}">
                <h4>${item.name}</h4>
                <p>${item.description}</p>
            `;

                menuList.appendChild(imgElement);
            });
        })
        .catch(error => console.error("無法載入圖片資料", error));
});
